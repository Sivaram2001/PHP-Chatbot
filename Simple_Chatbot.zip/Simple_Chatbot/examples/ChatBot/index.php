<!DOCTYPE html>
<html>
<head>
  <title>Simple ChatBot</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap-theme.css">
       <link rel="stylesheet" href="css/mobileui.css">
        <link rel="stylesheet" href="css/index.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
</head>

<body >
  
  <div class="typingEffect ">
  <h1> 
  <span
     class="txt-rotate"
     data-period="2000"
     data-rotate='[ "Our Project", "Simple ChatBot.", "Using PHP", "Have Fun!", "...." ]'></span>
</h1> 
</div>
<div class="main">

  <div class="iphoneX">
    <div class="screen">
      <div class="screen1">
  </div>
<div class="row row-centered pos">

<div class="chat">
<a style="text-decoration:none;" href="#"><div id="sc"><center ><b>Chat</b></center></div></a>
<div id="panel">
  
<div id="progressbar"></div>

<!-- Typing css Effect-->

<script type="text/javascript">
  var TxtRotate = function(el, toRotate, period) {
  this.toRotate = toRotate;
  this.el = el;
  this.loopNum = 0;
  this.period = parseInt(period, 10) || 2000;
  this.txt = '';
  this.tick();
  this.isDeleting = false;
};

TxtRotate.prototype.tick = function() {
  var i = this.loopNum % this.toRotate.length;
  var fullTxt = this.toRotate[i];

  if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
  } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
  }

  this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

  var that = this;
  var delta = 300 - Math.random() * 100;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function() {
    that.tick();
  }, delta);
};

window.onload = function() {
  var elements = document.getElementsByClassName('txt-rotate');
  for (var i=0; i<elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-rotate');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtRotate(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #666 }";
  document.body.appendChild(css);
};
</script>
<script>

$(document).ready(function(){

    var i=0;
    var st;

    $("#sc").click(function(){

         
          i++;

          $("#panel").slideToggle();

          if(i==1)
          {
              $('#div').html("<div class=\"ou\"> Hello Guest. Welcome To AI Chat</div><br>");

          }
          

           

        });



});



</script>


<script type="text/javascript">
  
  $(document).ready(function(){

     $("#st").click(function(){

           var str=$("#tt").val();
  
           $("#div").html(str);



     });

  });


</script>

<script>
//wait for page load to initialize script
$(document).ready(function(){

 window.alreadySubmit = false;

  $('#tt').keypress(function(f){

     
     if(f.which == 13 && !alreadySubmit) {
        window.alreadySubmit = true;

    //listen for form submission

    $('form').on('submit', function(e){
      //prevent form from submitting and leaving page
      e.preventDefault();

      // AJAX 
      $.ajax({
            type: "POST", //type of submit
            cache: false, //important or else you might get wrong data returned to you
            url: "process.php", //destination
            datatype: "html", //expected data format from process.php
            data: $('form').serialize(), //target your form's data and serialize for a POST
            success: function(result) { // data is the var which holds the output of your process.php

                // locate the div with #result and fill it with returned data from process.php
               

                $('#div').append("<div class=\"stt\""+result+"</div>");

                $('#tt').val("");

            }
        });
    });
  }
    
       
  
});

   
});

               
</script>

<div id='div' name="output" >
  
  <div id="div1"></div>


</div>
<br>

<!--<script>
"use strict";
function submitForm(oFormElement)
{
  var xhr = new XMLHttpRequest();
  var display=document.getElementById('div');
  xhr.onload = function(){ display.innerHTML=xhr.responseText; }
  xhr.open (oFormElement.method, oFormElement.action, true);
  xhr.send (new FormData (oFormElement));
  return false;
}
</script>-->
<!--<label for="out">Output</label>
<textarea id='div' class="form-control" name="output" rows="10" cols="50"></textarea><br><br>-->

<div class="form-group">
<form action="process.php" id="form" name="f2" method="POST" >
<div class="typing-field">
  <div class="input-data">
    <input type="textarea" id="tt" name="input" placeholder="Type Your Message" required autocomplete="off"/>
</div>
</div>
</form>


</div>

</div>
</div>


</div></div>
</div></div>
</div>

</body>
</html>