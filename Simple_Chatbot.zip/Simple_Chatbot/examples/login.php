<?php 

session_start();

?>

<!DOCTYPE html>
<head>
  <title>Login</title>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link href="sb-admin-2.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="../assets/img/Clogo.png">
<style>
#txt{
font-size:35px;
font-family:sans-serif;
position:relative;
text-align:center;
padding:10px;
}

.form-group a {
  text-decoration:none;
}
</style>
<script>
function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
var mid = ' ';
 h = h % 12;
  h = h ? h : 12; // the hour '0' should be '12'
  m = m < 10 ? ''+m : m;

    if (m < 10) {
      m = "" + m;
    }
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('txt').innerHTML =
  h + ":" + m + ":" + s + "" +mid;
  var t = setTimeout(startTime, 500);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
</head>



<body class="bg-gradient-primary">
<br><br>
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            
              
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Hey Buddy, The Time is<body onload="startTime()">
                      <div id="txt"></div>

</body></h1>
		<form action="login.php" method="post" name="Login_Form" class="form-signin">  
			     
			  <div class="form-group">
			  <input type="text"class="form-control form-control-user" name="username" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Username" required="" autofocus="" autocomplete="off"/>
			  </div>
			  <br>
                    <div class="form-group">
			  <input type="password" class="form-control1 form-control inputloginpass" name="password" id="exampleInputPassword" placeholder="Password" required=""/> 
			  </div>
			  <br>
                    <div class="form-group">    		  	
			  <button class="btn btn-primary btn-user btn-block"  name="login" value="Login" type="Submit">LOGIN</button>  			
		</form>		
  </div>
  <div class="form-group">    		  	
			 <a href="index.html"> <button class="btn btn-danger btn-user btn-block"  name="login" type="Submit">BACK</button> </a> 			
		</form>		
	</div>	
</div>
</div>
                </div>
              
            
          </div>
        </div>

      </div>

    </div>

  </div>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
  </html>




<?php 

//make connection
$con = new mysqli('localhost','root','','users');

if ($con->connect_error){
	die("connection error");
}
else{
	echo "";
}

if(isset($_POST['login'])) {
	
     $user_name = $_POST['username'];
     $user_password = $_POST['password'];
	 
	 $encrypt = md5($user_password);
	 
	 $login_query = "SELECT `name`, `password` FROM `admin` WHERE username='$user_name' AND password='$user_password'";
	 
	  $run = mysqli_query($con,$login_query);
	  
	  if(mysqli_num_rows($run)>0) { 
		   
		   $_SESSION['name'] = $user_name;
		   
		   echo "<script>window.open('dashboard.html','_self')</script>";
	          }
	  else
  		  {
		  echo "<script>alert('Username or password is wrong')</script>";
	       }
	  
   }
	  ?>